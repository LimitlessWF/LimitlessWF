# Limitless — Warframe Market Sniper

**⚠️ EXPERIMENTAL — TEST ⚠️**

Limitless is a slow, ethical deal notification tool for Warframe Market. It monitors listings and alerts you when items matching your criteria appear at or below your target price. **It does not auto-buy. It does not snipe faster than a human can. It does not violate Digital Extremes' Terms of Service.**

This is a **time-limited experiment** to gauge community interest and gather feedback. The backend may go offline at any time without notice.

### Can I get banned from warframe.market for using this?

**No.** Your client only talks to the LimitlessWF backend server — it never directly contacts warframe.market. All API requests are made from the server at a respectful, rate-limited interval. Warframe.market sees one server checking listings slowly, not your personal IP making rapid requests.

If the server ever gets rate-limited, it affects the backend — not individual users.

# LimitlessWF License

## Allowed
- Use the tool as-is for personal Warframe trading
- Modify the notification sound (not.mp3)
- Share the unmodified tool with other players
- Learn from the code and build your own projects

## Not Allowed
- Selling this software or any derivative
- Redistributing modified versions that bypass the fair use limits
- Claiming authorship of this work
- Using any part of this project to harm, harass, or exploit other players

## Disclaimer
This tool is provided for educational and community purposes. The author assumes no liability for how it is used.
---

## How It Works

1. You set an alert (e.g., "Mesa Prime Set under 70 platinum")
2. The server checks listings at a respectful, non-aggressive interval
3. When a matching deal is found, you get a notification with a ready-to-paste whisper
4. **You still have to message the seller yourself and complete the trade in-game**

Limitless is a notification tool — not a bot, not an auto-trader, not a market manipulator.

---

## Features

- Prime/item price alerts
- Riven stat-based alerts (weapon + positive stats + optional negative)
- Ready-to-paste `/w` whisper copied to clipboard
- Optional sound notification
- 3 alert slots per user
- Number-based alert management (type "1" to remove, not the full slug)

---

## Installation

### Prerequisites

- Python 3.10+
- pip

### Setup

```bash
git clone https://github.com/LimitlessWF/limitless.git
cd limitless
pip install -r requirements.txt