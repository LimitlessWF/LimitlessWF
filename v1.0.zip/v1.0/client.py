"""
LIMITLESS CLIENT — Warframe Market Sniper
==========================================
ASCII terminal client. Connects to the Limitless backend server.
Add alerts, listen for deals, get clipboard whispers.

Usage:
    python client.py

Requires:
    pip install requests pyperclip
    (pygame optional — for sound notifications)
"""

import json
import os
import sys
import threading
import time
from datetime import datetime

import requests
import pyperclip
import webbrowser

# Optional sound support
try:
    import pygame
    PYGAME_AVAILABLE = True
except ImportError:
    PYGAME_AVAILABLE = False
    print("(Sound disabled — install pygame for deal alerts)")


# ============================================================================
# CONFIGURATION
# ============================================================================

CONFIG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "client_config.json")

listener = None

DEFAULT_CONFIG = {
    "server_url": "http://89.168.68.199:5051",
    "poll_interval_seconds": 3,
    "sound_enabled": True,
    "sound_file": "not.mp3",
    "clipboard_enabled": True
}


def load_config():
    if os.path.exists(CONFIG_PATH):
        with open(CONFIG_PATH, 'r') as f:
            return {**DEFAULT_CONFIG, **json.load(f)}
    else:
        save_config(DEFAULT_CONFIG)
        return DEFAULT_CONFIG.copy()


def save_config(config):
    with open(CONFIG_PATH, 'w') as f:
        json.dump(config, f, indent=2)


CONFIG = load_config()
SERVER_URL = CONFIG["server_url"].rstrip('/')

# ============================================================================
# SOUND
# ============================================================================

def play_sound():
    """Play the deal notification sound."""
    if not CONFIG["sound_enabled"] or not PYGAME_AVAILABLE:
        return
    
    try:
        sound_file = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                  CONFIG["sound_file"])
        if os.path.exists(sound_file):
            pygame.mixer.init()
            sound = pygame.mixer.Sound(sound_file)
            sound.play()
    except Exception as e:
        pass  # Never crash because of sound


# ============================================================================
# API HELPERS
# ============================================================================

def api_request(method, endpoint, data=None, timeout=10):
    """Make a request to the backend. Returns (success, data/error_message)."""
    url = f"{SERVER_URL}{endpoint}"
    
    try:
        if method == 'GET':
            resp = requests.get(url, params=data, timeout=timeout)
        elif method == 'POST':
            resp = requests.post(url, json=data, timeout=timeout)
        else:
            return False, f"Unknown method: {method}"
        
        if resp.status_code == 200:
            return True, resp.json()
        else:
            try:
                error = resp.json().get('error', f'HTTP {resp.status_code}')
            except:
                error = f'HTTP {resp.status_code}'
            return False, error
    except requests.exceptions.ConnectionError:
        return False, f"Cannot connect to server at {SERVER_URL}"
    except requests.exceptions.Timeout:
        return False, "Request timed out"
    except Exception as e:
        return False, str(e)


def add_prime_alert(item, max_price):
    """Add a prime/item alert."""
    return api_request('POST', '/api/alert/add', {
        'type': 'prime',
        'item': item,
        'max_price': max_price
    })


def add_riven_alert(weapon, positive_stats, negative_stat, max_price):
    """Add a riven alert."""
    return api_request('POST', '/api/alert/add', {
        'type': 'riven',
        'weapon': weapon,
        'positive_stats': positive_stats,
        'negative_stat': negative_stat,
        'max_price': max_price
    })


def remove_alert(alert_id):
    """Remove an alert by ID."""
    return api_request('POST', '/api/alert/remove', {'alert_id': alert_id})


def list_alerts():
    """Get all active alerts."""
    return api_request('GET', '/api/alerts')


def get_events(alert_id, last_id=0):
    """Poll events for an alert."""
    return api_request('GET', '/api/events', {
        'alert_id': alert_id,
        'last_id': last_id
    })


def search_rivens(weapon, max_price=None):
    """Manual riven search."""
    data = {'weapon': weapon}
    if max_price:
        data['max_price'] = max_price
    return api_request('POST', '/api/riven/search', data)


def check_health():
    """Check backend health."""
    return api_request('GET', '/api/health')

def open_discord():
    """Open Discord server invite in default browser."""
    invite_url = "https://discord.gg/jKPmxWcqY"  # ← put your invite here
    print("\n  🌐 Opening Discord invite in your browser...")
    try:
        webbrowser.open(invite_url)
        print("  ✅ Browser opened. If not, visit:")
        print(f"  {invite_url}")
    except Exception:
        print(f"  ❌ Couldn't open browser. Visit: {invite_url}")

# ============================================================================
# EVENT LISTENER (Background Thread)
# ============================================================================

class EventListener:
    """Polls backend for deal events — only for alerts THIS client created."""
    
    def __init__(self):
        self.running = True
        self.my_alerts = []  # Only alert IDs this client created
        self.last_ids = {}   # alert_id -> last_event_id
        self.thread = None
    
    def start(self):
        self.thread = threading.Thread(target=self._poll_loop, daemon=True)
        self.thread.start()
    
    def stop(self):
        self.running = False
    
    def add_alert(self, alert_id):
        """Track a new alert created by this client."""
        if alert_id not in self.my_alerts:
            self.my_alerts.append(alert_id)
            self.last_ids[alert_id] = 0
    
    def remove_alert(self, alert_id):
        """Stop tracking a removed alert."""
        if alert_id in self.my_alerts:
            self.my_alerts.remove(alert_id)
            self.last_ids.pop(alert_id, None)
    
    def _poll_loop(self):
        poll_interval = CONFIG["poll_interval_seconds"]
        
        while self.running:
            try:
                for alert_id in self.my_alerts:
                    last_id = self.last_ids.get(alert_id, 0)
                    
                    ok, events_data = get_events(alert_id, last_id)
                    if ok:
                        events = events_data.get('events', [])
                        for event in events:
                            self._display_event(event)
                            self.last_ids[alert_id] = max(
                                self.last_ids[alert_id],
                                event['id']
                            )
            except Exception as e:
                pass  # Silently retry next cycle
            
            time.sleep(poll_interval)
    
    def _display_event(self, event):
        """Print a deal to the terminal and handle clipboard/sound."""
        atype = event.get('type', '?')
        item = event.get('item', 'Unknown')
        price = event.get('price', 0)
        seller = event.get('seller', 'Unknown')
        whisper = event.get('whisper', '')
        stats = event.get('stats', '')
        
        print()
        print("  " + "=" * 55)
        print("  🔥  DEAL SNIPED!")
        print("  " + "-" * 55)
        
        if atype == 'prime':
            print(f"  Item:    {item}")
        elif atype == 'riven':
            print(f"  Riven:   {item}")
            if stats:
                print(f"  Stats:   {stats}")
        
        print(f"  Price:   {price} platinum")
        print(f"  Seller:  {seller}")
        print("  " + "-" * 55)
        print(f"  Whisper: {whisper[:70]}...")
        print("  " + "=" * 55)
        print()
        
        if CONFIG["clipboard_enabled"] and whisper:
            try:
                pyperclip.copy(whisper)
                print("  📋 Whisper copied to clipboard!")
            except Exception:
                pass
        
        play_sound()


# ============================================================================
# TERMINAL UI
# ============================================================================

def print_banner():
    print("""
    ╔══════════════════════════════════════════════════╗
    ║            L I M I T L E S S  Client             ║
    ║         Warframe Market Sniper Terminal           ║
    ╚══════════════════════════════════════════════════╝
    """)


def print_menu():
    print("""
    ┌──────────────────────────────────────────────────┐
    │  [1] Add Prime Alert                             │
    │  [2] Add Riven Alert                             │
    │  [3] List Active Alerts                          │
    │  [4] Remove Alert                                │
    │  [5] Server Health                               │
    │  [6] Manual Riven Search                         │
    │  [7] Exit                                        │
    │  [8] Join Discord                                │
    └──────────────────────────────────────────────────┘
    """)


def handle_add_prime():
    """Interactive: add a prime alert."""
    print("\n  ── ADD PRIME ALERT ──")
    item = input("  Item slug (e.g., mesa_prime_set): ").strip().lower()
    if not item:
        print("  ❌ Cancelled.")
        return
    
    try:
        price = int(input("  Max price (platinum): ").strip())
    except ValueError:
        print("  ❌ Invalid price.")
        return
    
    print(f"  Adding alert: {item} <= {price}p ...")
    success, data = add_prime_alert(item, price)
    
    if success:
        alert_id = data.get('alert_id', '?')
        listener.add_alert(alert_id)
        print(f"  ✅ Alert added! ID: {alert_id}")
    else:
        print(f"  ❌ Failed: {data}")


def handle_add_riven():
    """Interactive: add a riven alert."""
    print("\n  ── ADD RIVEN ALERT ──")
    weapon = input("  Weapon slug (e.g., rubico): ").strip().lower()
    if not weapon:
        print("  ❌ Cancelled.")
        return
    
    stats_input = input("  Positive stats (comma separated, e.g., Critical Chance, Critical Damage): ").strip()
    positive_stats = [s.strip() for s in stats_input.split(',') if s.strip()]
    
    if not positive_stats:
        print("  ❌ At least one stat required.")
        return
    
    neg_input = input("  Negative stat (optional, press Enter to skip): ").strip()
    negative_stat = neg_input if neg_input else None
    
    try:
        price = int(input("  Max price (platinum): ").strip())
    except ValueError:
        print("  ❌ Invalid price.")
        return
    
    print(f"  Adding alert: {weapon} [{', '.join(positive_stats)}] <= {price}p ...")
    success, data = add_riven_alert(weapon, positive_stats, negative_stat, price)
    
    if success:
        alert_id = data.get('alert_id', '?')
        listener.add_alert(alert_id)
        print(f"  ✅ Alert added! ID: {alert_id}")
    else:
        print(f"  ❌ Failed: {data}")


def handle_list_alerts():
    """Display only alerts created by THIS client."""
    print("\n  ── ACTIVE ALERTS ──")
    
    if not listener.my_alerts:
        print("  (no active alerts)")
        return
    
    # Fetch all alerts from server (we need details)
    success, data = list_alerts()
    
    if not success:
        print(f"  ❌ Failed: {data}")
        return
    
    all_alerts = data.get('alerts', [])
    
    # Filter to only our alerts
    our_alerts = [a for a in all_alerts if a.get('id') in listener.my_alerts]
    
    if not our_alerts:
        print("  (no active alerts)")
        return
    
    for i, alert in enumerate(our_alerts, 1):
        alert_id = alert.get('id', '?')
        atype = alert.get('type', '?').upper()
        
        if atype == 'PRIME':
            desc = f"{alert.get('item', '?')}"
        else:
            stats = ', '.join(alert.get('positive_stats', [])[:2])
            desc = f"{alert.get('weapon', '?')} [{stats}]"
        
        print(f"  [{i}] [#{alert_id}] [{atype}] {desc} <= {alert.get('max_price', '?')}p")


def handle_remove_alert():
    """Remove an alert by its list number (1, 2, 3...)."""
    print("\n  ── REMOVE ALERT ──")
    
    # Fetch current alerts
    success, data = list_alerts()
    if not success:
        print(f"  ❌ Failed to fetch alerts: {data}")
        return
    
    alerts_list = data.get('alerts', [])
    
    if not alerts_list:
        print("  (no active alerts to remove)")
        return
    
    # Show them numbered
    print()
    for i, alert in enumerate(alerts_list, 1):
        alert_id = alert.get('id', '?')
        atype = alert.get('type', '?').upper()
        
        if atype == 'PRIME':
            desc = f"{alert.get('item', '?')}"
        else:
            stats = ', '.join(alert.get('positive_stats', [])[:2])
            desc = f"{alert.get('weapon', '?')} [{stats}]"
        
        print(f"  [{i}] [{atype}] {desc} <= {alert.get('max_price', '?')}p")
    
    print()
    
    # Let user pick by number
    choice = input("  Alert number to remove (or Enter to cancel): ").strip()
    if not choice:
        print("  ❌ Cancelled.")
        return
    
    try:
        index = int(choice) - 1
        if index < 0 or index >= len(alerts_list):
            print("  ❌ Invalid number.")
            return
    except ValueError:
        print("  ❌ Enter a number.")
        return
    
    alert_id = alerts_list[index]['id']
    success, data = remove_alert(alert_id)
    
    if success:
        desc = alerts_list[index].get('item') or alerts_list[index].get('weapon', '?')
        listener.remove_alert(alert_id)
        print(f"  ✅ Removed alert [{choice}]: {desc}")
    else:
        print(f"  ❌ Failed: {data}")


def handle_health():
    """Check backend health."""
    print("\n  ── SERVER HEALTH ──")
    success, data = check_health()
    
    if success:
        print(f"  Backend:    {data.get('backend', '?')}")
        print(f"  WF Market:  {data.get('wf_market', '?')}")
        print(f"  Alerts:     {data.get('alerts_active', 0)}")
        print(f"  Uptime:     {data.get('uptime_seconds', 0):.0f}s")
    else:
        print(f"  ❌ Cannot reach server: {data}")


def handle_search_rivens():
    """Manual riven search."""
    print("\n  ── MANUAL RIVEN SEARCH ──")
    weapon = input("  Weapon slug (e.g., rubico): ").strip().lower()
    if not weapon:
        print("  ❌ Cancelled.")
        return
    
    max_price_input = input("  Max price (optional, press Enter to skip): ").strip()
    max_price = int(max_price_input) if max_price_input else None
    
    print(f"  Searching rivens for {weapon}...")
    success, data = search_rivens(weapon, max_price)
    
    if not success:
        print(f"  ❌ Failed: {data}")
        return
    
    rivens = data.get('rivens', [])
    count = data.get('count', 0)
    
    print(f"\n  Found {count} rivens for {weapon}:")
    print("  " + "-" * 50)
    
    for i, riven in enumerate(rivens[:10], 1):
        stats = ', '.join(riven.get('positive_stats', [])[:2])
        neg = riven.get('negative_stat', '')
        if neg:
            stats += f" ({neg})"
        print(f"  {i:2d}. {riven['price']:5d}p | {riven['seller'][:20]:20s} | {stats}")
    
    if count > 10:
        print(f"  ...and {count - 10} more")


# ============================================================================
# MAIN
# ============================================================================

def main():
    print_banner()
    
    # Load config
    config = CONFIG
    
    print(f"  Server: {SERVER_URL}")
    print(f"  Sound:  {'ON' if config['sound_enabled'] and PYGAME_AVAILABLE else 'OFF'}")
    print()
    
    # Test connection
    print("  Testing connection to server...")
    success, data = check_health()
    
    if success:
        print(f"  ✅ Connected! Backend status: {data.get('status', 'ok')}")
        print(f"  WF Market: {data.get('wf_market', '?')}")
    else:
        print(f"  ⚠️  Warning: {data}")
        print("  (Client will run, but deals may not work)")
    
    print()
    print("  🔍 Listening for deals in background...")
    print("  (Deals will appear here automatically)")
    
    # Start event listener
    global listener
    listener = EventListener()
    listener.start()
    
    # Main menu loop
    try:
        while True:
            print_menu()
            choice = input("  > ").strip()
            
            if choice == '1':
                handle_add_prime()
            elif choice == '2':
                handle_add_riven()
            elif choice == '3':
                handle_list_alerts()
            elif choice == '4':
                handle_remove_alert()
            elif choice == '5':
                handle_health()
            elif choice == '6':
                handle_search_rivens()
            elif choice == '7':
                print("\n  👋 Goodbye, Tenno.")    
                break
            elif choice == '8':
                 open_discord()
            else:
                print("  ❌ Invalid choice.")
    
    except KeyboardInterrupt:
        print("\n\n  👋 Interrupted. Goodbye!")
    
    finally:
        listener.stop()


if __name__ == '__main__':
    main()